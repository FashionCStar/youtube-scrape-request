# YouTube Scrape
A YouTube search scraping API
## Get search results
The base url to get search results, is as follows:<br>
```
http://youtube-scrape.herokuapp.com/api/search
```
The url query options are as follows:
<table>
  <thead>
    	<tr>
        <th>Query</th>
        <th>Type</th>
        <th>Description</th>
    	</tr>
  </thead>
  <tbody>
		<tr>
        <td>q</td>
        <td>String</td>
        <td>YouTube search query</td>
    	</tr>
    	<tr>
        <td>page</td>
        <td>Number</td>
        <td>The page of YouTube search results</td>
    	</tr>
  </tbody>
</table>

Note that if no page is specified the default is 1
Here is an example call:
```
http://youtube-scrape.herokuapp.com/api/search?q=herman%20fassett&page=1
```
Example output:
```
{
	"results": [{
			"channel": {
				"id": "UCsOlslmdfxy6aG3O9Xkh5kA",
				"title": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"snippet": "I've always loved playing around with music, and here I just upload what I come up with when I find the time and inspiration.",
				"thumbnail_src": "//yt3.ggpht.com/a/AATXAJyN0lSWv-uFWlcLKD46Oq5-I8i1mbnlqnLE2-F15A=s176-c-k-c0x00ffffff-no-rj-mo",
				"video_count": "16 videos",
				"subscriber_count": "34 subscribers"
			}
		},
		{
			"video": {
				"id": "xprYPd5QxhA",
				"title": "One Summer Night (Cover) - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=xprYPd5QxhA",
				"duration": "3:14",
				"snippet": "Here's a quick cover of One Summer Night which I think was originally sung by Chelsia Chan and Kenny Bee.",
				"upload_date": "4 months ago",
				"thumbnail_src": "https://i.ytimg.com/vi/xprYPd5QxhA/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLC_lPQPmdmVu3icbFkKw9GyOJO9Qg",
				"views": "210 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"playlist": {
				"id": "PLCgnza08eA91orhHvNPTp_gEjECGyV9HT",
				"title": "Top Tracks - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=IyvhwAC9TjE&list=PLCgnza08eA91orhHvNPTp_gEjECGyV9HT",
				"thumbnail_src": "https://i.ytimg.com/vi/IyvhwAC9TjE/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLCyUXrIe-5Outvjgt1nmAO3QGeMJw",
				"video_count": "8"
			},
			"uploader": {
				"username": "Herman Fassett - Topic",
				"url": "https://www.youtube.com/channel/UCDKLO7jQj_lq3_mq0ynlrAg"
			}
		},
		{
			"video": {
				"id": "UYDxk7ZKvS0",
				"title": "Power - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=UYDxk7ZKvS0",
				"duration": "5:09",
				"snippet": "This is a bit more of an experimental piece I've been putting time into here and there for many months. The instrumentation is a ...",
				"upload_date": "1 year ago",
				"thumbnail_src": "https://i.ytimg.com/vi/UYDxk7ZKvS0/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDzl0TOq-F_nv2JjfM_VW3etBdZ2A",
				"views": "89 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "nv7xf0MUFzw",
				"title": "The Path To Freedom - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=nv7xf0MUFzw",
				"duration": "3:31",
				"snippet": "I wanted to change a few things to this piece, but I've been really busy and haven't uploaded anything in awhile. So, here it is as it ...",
				"upload_date": "5 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/nv7xf0MUFzw/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLCfOaMBqB2Josadm0NP1y9Eka2dBQ",
				"views": "177 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "Za7OZ6MsmjU",
				"title": "A Winter Day - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=Za7OZ6MsmjU",
				"duration": "3:24",
				"snippet": "Here's my Christmas / Winter / New Year piece. I created it a few days back, but made a few minor adjustments today. Image used: ...",
				"upload_date": "5 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/Za7OZ6MsmjU/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLBpsF7VGRrPApjRrJVocE5dA1UGvQ",
				"views": "100 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "WGYqoa0iePs",
				"title": "After Harvest - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=WGYqoa0iePs",
				"duration": "2:13",
				"snippet": "I actually wrote this piece nearly 3 months ago and it was the quickest composition I've ever made. However, I've been distracted ...",
				"upload_date": "4 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/WGYqoa0iePs/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLBhC9LVfywvpOFwlIZ0kmOHiaRvrw",
				"views": "58 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "N2RhnMPbOPc",
				"title": "Our Barren Lands (Cello) - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=N2RhnMPbOPc",
				"duration": "3:05",
				"snippet": "I actually had this cello melody sort of lying around and thought I'd pull it out really quickly for this contest: ...",
				"upload_date": "4 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/N2RhnMPbOPc/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLBQ6kgY7npbyS9vReamwqqZzsQj4Q",
				"views": "59 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "xDeNtHCLN88",
				"title": "It's December Once Again - Herman Fassett (#RoomieMelody)",
				"url": "https://www.youtube.com/watch?v=xDeNtHCLN88",
				"duration": "3:51",
				"snippet": "This is my entry into the #RoomieMelody challenge. I decided there can never be too many Christmas songs... Challenge origin ...",
				"upload_date": "6 months ago",
				"thumbnail_src": "https://i.ytimg.com/vi/xDeNtHCLN88/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDWOgUQuOCMfesf06uJj5Ra8ob46Q",
				"views": "174 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "ykYTImq7p9A",
				"title": "Growth - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=ykYTImq7p9A",
				"duration": "3:28",
				"snippet": "A piece I've had in the works for a long time and have only just decided on a name. This is to signify the change around us as we ...",
				"upload_date": "4 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/ykYTImq7p9A/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLBgEasKTHDyoiJuaVYYDwiR2zA_4g",
				"views": "69 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "7EY2qJ9vQHI",
				"title": "Sunrise - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=7EY2qJ9vQHI",
				"duration": "2:36",
				"snippet": "This is a song I wrote during my Thanksgiving break. I hope to be writing more pieces now that Christmas break here (or close).",
				"upload_date": "5 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/7EY2qJ9vQHI/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDZg9edae9-S9R_qRziTaYCcFm5eQ",
				"views": "292 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "fnpvgyuooPs",
				"title": "Exiled - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=fnpvgyuooPs",
				"duration": "2:01",
				"snippet": "My friends have been asking me what I really do all day... No, this isn't everything, but it's what I spent the majority of my Veteran's ...",
				"upload_date": "5 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/fnpvgyuooPs/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDRiPeann4Xydi555vL03jvld-bxA",
				"views": "140 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "d5JAd7N3mBY",
				"title": "Snowfall - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=d5JAd7N3mBY",
				"duration": "2:52",
				"snippet": "Merry Christmas! This is my winter Christmas music this year -- actually I composed this as a gift to one of my sisters. ;) The video ...",
				"upload_date": "4 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/d5JAd7N3mBY/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDrcOyeYxp0YXoLs4AS6iZO1Vqk2w",
				"views": "61 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "nn7Ogr2x1ho",
				"title": "God Rest Ye Merry Gentlemen - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=nn7Ogr2x1ho",
				"duration": "4:21",
				"snippet": "A few hours of recording and mixing got me this. Nothing fancy, and so I was hoping to put some video story to it but yeah, didn't ...",
				"upload_date": "2 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/nn7Ogr2x1ho/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLCLzCWHUpiwvIViVlAFWRZVS51cgA",
				"views": "52 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "nRWJdaymQdg",
				"title": "Blessed are Those Who Mourn - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=nRWJdaymQdg",
				"duration": "3:23",
				"snippet": "This is a re-mixed version of a piece I wrote for the Documentary \"Echoes from The Heart\" on Gerondissa Makrina by Fiery ...",
				"upload_date": "2 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/nRWJdaymQdg/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDUDXzJfA9P7WF_5LwjenGSoVbg-g",
				"views": "110 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "p3REFOpIx6c",
				"title": "Darkness Comes (WOT Fan Music) - Herman Fassett",
				"url": "https://www.youtube.com/watch?v=p3REFOpIx6c",
				"duration": "3:22",
				"snippet": "This piece is kind of playing around with a very different style than I have ever done before, and I have also been reading the ...",
				"upload_date": "4 years ago",
				"thumbnail_src": "https://i.ytimg.com/vi/p3REFOpIx6c/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLCWOV3Dc0fGmQIyim8ObATL3Ix-8A",
				"views": "79 views"
			},
			"uploader": {
				"username": "Herman Fassett",
				"url": "https://www.youtube.com/channel/UCsOlslmdfxy6aG3O9Xkh5kA",
				"verified": false
			}
		},
		{
			"video": {
				"id": "Q5BO7SrqGng",
				"title": "Brightness Davar",
				"url": "https://www.youtube.com/watch?v=Q5BO7SrqGng",
				"duration": "6:58",
				"snippet": "Provided to YouTube by Soundrop Brightness Davar · <b>Herman Fassett</b> Growth ℗ 2017 <b>Herman Fassett</b> Released on: 2017-08-05 ...",
				"upload_date": "Live",
				"thumbnail_src": "https://i.ytimg.com/vi/Q5BO7SrqGng/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLD_zDfJApTvX8sb5x3Xjwva625OpQ",
				"views": "No views"
			},
			"uploader": {
				"username": "Herman Fassett - Topic",
				"url": "https://www.youtube.com/channel/UCDKLO7jQj_lq3_mq0ynlrAg",
				"verified": false
			}
		},
		{
			"video": {
				"id": "IyvhwAC9TjE",
				"title": "Darkness Comes",
				"url": "https://www.youtube.com/watch?v=IyvhwAC9TjE",
				"duration": "3:19",
				"snippet": "Provided to YouTube by Soundrop Darkness Comes · <b>Herman Fassett</b> Growth ℗ 2017 <b>Herman Fassett</b> Released on: 2017-08-05 ...",
				"upload_date": "Live",
				"thumbnail_src": "https://i.ytimg.com/vi/IyvhwAC9TjE/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLA_p6RiCj6PuT4PfDI527ixPALe1Q",
				"views": "2 views"
			},
			"uploader": {
				"username": "Herman Fassett - Topic",
				"url": "https://www.youtube.com/channel/UCDKLO7jQj_lq3_mq0ynlrAg",
				"verified": false
			}
		},
		{
			"video": {
				"id": "_7TFT9CCN4Q",
				"title": "The Path to Freedom",
				"url": "https://www.youtube.com/watch?v=_7TFT9CCN4Q",
				"duration": "3:30",
				"snippet": "Provided to YouTube by Soundrop The Path to Freedom · <b>Herman Fassett</b> Growth ℗ 2017 <b>Herman Fassett</b> Released on: ...",
				"upload_date": "Live",
				"thumbnail_src": "https://i.ytimg.com/vi/_7TFT9CCN4Q/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLBIfZIt397p2uwS1ULiT9bqNstTMQ",
				"views": "4 views"
			},
			"uploader": {
				"username": "Herman Fassett - Topic",
				"url": "https://www.youtube.com/channel/UCDKLO7jQj_lq3_mq0ynlrAg",
				"verified": false
			}
		},
		{
			"video": {
				"id": "DFMIl2nhJ7U",
				"title": "Sunrise",
				"url": "https://www.youtube.com/watch?v=DFMIl2nhJ7U",
				"duration": "2:34",
				"snippet": "Provided to YouTube by Soundrop Sunrise · <b>Herman Fassett</b> Growth ℗ 2017 <b>Herman Fassett</b> Released on: 2017-08-05 ...",
				"upload_date": "Live",
				"thumbnail_src": "https://i.ytimg.com/vi/DFMIl2nhJ7U/hqdefault.jpg?sqp=-oaymwEjCNACELwBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDWIIiPmq03jgLQpBwb9soCXcoLEQ",
				"views": "2 views"
			},
			"uploader": {
				"username": "Herman Fassett - Topic",
				"url": "https://www.youtube.com/channel/UCDKLO7jQj_lq3_mq0ynlrAg",
				"verified": false
			}
		}
	],
	"version": "0.1.0",
	"parser": "json_format"
}
```
Deploy To Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

